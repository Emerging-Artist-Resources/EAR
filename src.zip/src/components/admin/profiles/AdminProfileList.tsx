"use client"

import { AdminProfileItem, isNewProfile } from "./profile-types"
import { Card } from "@/components/ui/card"
import { Text } from "@/components/ui/typography"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { AdminProfileCard } from "./AdminProfileCard"

export function AdminProfileList({
  items,
  onUpdate,
  onMarkReviewed,
}: {
  items: AdminProfileItem[]
  onUpdate: (id: string, status: "emerging" | "established") => Promise<void>
  onMarkReviewed: (id: string) => Promise<void>
}) {
  if (!items.length) {
    return (
      <Card className="p-8 text-center">
        <Text className="text-[var(--gray-600)]">No profiles found.</Text>
      </Card>
    )
  }

  return (
    <div className="overflow-x-auto rounded-md border border-[var(--gray-200)] bg-white">
      <table className="min-w-full text-sm">
        <thead className="bg-[var(--gray-50)] text-[var(--gray-700)]">
          <tr>
            <th className="px-3 py-2 text-left">Name</th>
            <th className="px-3 py-2 text-left">Email</th>
            <th className="px-3 py-2 text-left">Type</th>
            <th className="px-3 py-2 text-left">Status</th>
            <th className="px-3 py-2 text-left">Created</th>
            <th className="px-3 py-2" />
          </tr>
        </thead>
        <tbody>
          {items.map((profile) => {
            const created = new Date(profile.createdAt).toLocaleString()
            const isNew = isNewProfile(profile)
            const isReviewed = !!profile.reviewedAt
            
            return (
              <tr
                key={profile.id}
                className={`border-t border-[var(--gray-200)] ${
                  isNew && !isReviewed ? "bg-[var(--warning-50)]" : ""
                }`}
              >
                <td className="px-3 py-2">
                  <div className="flex items-center gap-2">
                    {profile.name || "—"}
                    {isNew && !isReviewed && (
                      <Badge variant="warning" size="sm">New</Badge>
                    )}
                  </div>
                </td>
                <td className="px-3 py-2">{profile.email || "—"}</td>
                <td className="px-3 py-2 capitalize">{profile.profileType || "—"}</td>
                <td className="px-3 py-2 capitalize">{profile.status}</td>
                <td className="px-3 py-2">{created}</td>
                <td className="px-3 py-2 text-right">
                  <div className="flex items-center justify-end gap-2">
                    {isNew && !isReviewed && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onMarkReviewed(profile.id)}
                        className="text-[var(--success-600)] border-[var(--success-300)] hover:bg-[var(--success-50)]"
                      >
                        ✓ Mark Reviewed
                      </Button>
                    )}
                    <AdminProfileCard
                      profile={profile}
                      onUpdate={onUpdate}
                      onMarkReviewed={onMarkReviewed}
                    />
                  </div>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

