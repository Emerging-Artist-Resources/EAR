"use client"

import { UseFormReturn } from "react-hook-form"
// import { Input } from "@/components/ui/input"
// import { Textarea } from "@/components/ui/textarea"
import { EventFormData } from "@/lib/validations/events"
import { Section } from "@/components/forms/blocks/Section"
import { TextField } from "@/components/forms/blocks/TextField"
import { TextAreaField } from "@/components/forms/blocks/TextAreaField"
import { DateTimeList } from "@/components/forms/blocks/DateTimeList"
import { LocationField } from "@/components/forms/blocks/LocationField"
import { PhotoUploader } from "@/components/forms/blocks/PhotoUploader"

interface AuditionStepProps {
  form: UseFormReturn<EventFormData>
}

export function AuditionStep({ form }: AuditionStepProps) {
  // consume form for fields via blocks
  // const e = errors as FieldErrors<EventFormData>

  return (
    <>
      <Section title="Audition Details">
        <TextField form={form} name={"auditionName"} label="Audition Name" required placeholder="Audition Name"/>
        <TextAreaField form={form} name={"aboutProject"} label="About the Project" required placeholder="About the Project/Company"/>
        <TextAreaField form={form} name={"eligibility"} label="Eligibility" required placeholder="Eligibility, age, style, experience, etc."/>
        <TextField form={form} name={"compensation"} label="Compensation" required placeholder="$ or description"/>
        <TextField form={form} name={"auditionLink"} label="Audition Submission" required placeholder="submission link or instructions"/>
        <TextField form={form} name={"auditionFee"} label="Audition Fee" required placeholder="$ or N/A"/>
      </Section>

      <Section title="Key Dates">
        <DateTimeList form={form} title="Audition Date" note="If you have multiple audition dates, list them in the additional information section" primaryDateName={"auditionDate"} primaryTimeName={"auditionTime"} required/>
        <DateTimeList form={form} title="Deadline" note="If you don't have a deadline, use the audition date" primaryDateName={"deadlineDate"} primaryTimeName={"deadlineTime"} required/>
      </Section>

      <Section title="Location">
        <LocationField form={form} addressName={"address"} instructionsName={"addressInstructions"} label="Audition Location" instructionsLabel="Additional Instructions" required />
      </Section>

      <Section title="Media Uploads">
        <PhotoUploader form={form} name={"promoFiles"} label="Promotional Images" description="Upload up to 5 images" />
        <TextAreaField form={form} name={"credits"} label="Image Description / Photo Credit" placeholder="Describe the images and provide photo credit" rows={3}/>
      </Section>

      <Section title="Credits & Socials">
        <TextAreaField form={form} name={"credits"} label="Credits" required placeholder="Teacher(s), Performer(s), etc."/>
        <TextField form={form} name={"socialHandles"} label="Social Handles" required placeholder="@username"/>
      </Section>

      <Section title="Additional Information">
        <TextAreaField form={form} name={"notes"} label="Anything else you'd like to know?" placeholder="Additional information" rows={4} />
      </Section>
    </>
  )
}