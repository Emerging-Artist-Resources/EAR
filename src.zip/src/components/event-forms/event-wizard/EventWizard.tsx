"use client"

import { useState, useCallback, useMemo } from "react"
import { useForm, zodResolver } from "@/lib/vendor/react-hook-form-zod"
import type { Resolver } from "react-hook-form"
import { eventFormSchema, type EventFormData } from "@/lib/validations/events"
import { Button } from "@/components/ui/button"
import { Alert } from "@/components/ui/alert"
import { type EventType } from "./EventTypeSelector"
import { BasicInfoStep } from "./steps/BasicInfoStep"
import { PerformanceDetailsStep } from "./steps/PerformanceDetailsStep"
import { ClassWorkshopStep } from "./steps/ClassWorkshopStep"
import { OpportunityStep } from "./steps/OpportunityStep"
import { AuditionStep } from "./steps/AuditionStep"
import { PageNumbers } from "@/components/forms/blocks/PageNumbers"
import { validateStep2 } from "./validation-helpers"
import { buildEventPayload, type UserInfo } from "./payload-builders"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"
import { apiPost } from "@/lib/fetch-utils"

interface EventWizardProps {
  onSuccess: () => void
  onClose: () => void
}

export function EventWizard({ onSuccess, onClose }: EventWizardProps) {
  const [step, setStep] = useState<1 | 2>(1)
  const [eventType, setEventType] = useState<EventType | null>(null)
  const [submitMessage, setSubmitMessage] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { user, userName } = useAuth()
  const { showToast } = useToast()

  // Derive userInfo from auth state
  const userInfo = useMemo<UserInfo | null>(() => {
    if (!user || !userName || !user.email) return null
    return {
      name: userName,
      email: user.email,
      pronouns: (user.user_metadata?.pronouns as string | undefined) || null,
    }
  }, [user, userName])


  const resolver = zodResolver(eventFormSchema) as unknown as Resolver<EventFormData>
  const form = useForm<EventFormData>({
    resolver,
    defaultValues: {
      agreeCompTickets: false,
      photoUrls: [""],
      address: "",
      // Seed one date card with one time for performance extras
      extraOccurrences: [{ date: "", times: [{ time: "" }] }],
    } as Partial<EventFormData>,
    mode: 'onChange',
    reValidateMode: 'onChange',
    shouldUnregister: true,
  })

  const goNext = useCallback(async () => {
    if (step === 1) {
      if (!eventType) {
        showToast("Please select an event type to continue", "warning")
        return
      }
      setStep(2)
      return
    }
    if (step === 2 && eventType) {
      const validation = await validateStep2(form, eventType)
      if (!validation.isValid) {
        showToast(validation.message || "Please complete required fields on this step", "error")
        return
      }
      // In 2-step flow, Step 2 is submit step; validation passed
      return
    }
  }, [step, eventType, form, showToast])

  const goBack = useCallback(() => {
    if (step === 1) return
    setStep(((step - 1) as 1 | 2))
  }, [step])

  const handleSubmit = form.handleSubmit(
    async (data) => {
      try {
        setIsSubmitting(true)
        setSubmitMessage("")

        if (!eventType) {
          setSubmitMessage("Please select an event type")
          setIsSubmitting(false)
          return
        }

        if (!userInfo) {
          setSubmitMessage("Please sign in to submit")
          setIsSubmitting(false)
          return
        }

        const payload = buildEventPayload(data, eventType, userInfo)

        // Additional validation for occurrences
        if (eventType === "PERFORMANCE" && payload.occurrences.length === 0) {
          setSubmitMessage("Please add at least one date & time")
          setIsSubmitting(false)
          return
        }

        if (eventType === "CLASS" && payload.occurrences.length === 0) {
          setSubmitMessage("Please provide at least one valid class date/time")
          setIsSubmitting(false)
          return
        }

        await apiPost("/api/events", payload)
        
        setSubmitMessage("Submitted successfully! Pending review.")
        showToast("Submitted successfully! Pending review.", "success")
        form.reset()
        
        // Navigate after success message
        setTimeout(() => {
          onSuccess()
          onClose()
        }, 1200)
      } catch (e) {
        const errorMessage = e instanceof Error ? e.message : "Something went wrong"
        setSubmitMessage(errorMessage)
        showToast(errorMessage, "error")
      } finally {
        setIsSubmitting(false)
      }
    },
    (errors) => {
      console.error("[submit] invalid form", errors)
      // Extract first error message for user feedback
      const firstError = Object.values(errors)[0]
      const errorMessage = firstError?.message || "Please check all required fields"
      setSubmitMessage(errorMessage)
      showToast(errorMessage, "error")
      setIsSubmitting(false)
    }
  )

  return (
    <div className="space-y-6">
      {/* Progress */}
      {/* {(() => {
        const progressPct = step === 1 ? 50 : 100
        return (
          <div className="w-full">
            <div className="h-2 bg-gray-200 rounded">
              <div
                className="h-2 bg-primary-400 rounded transition-all"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>
        )
      })()} */}
      {/* Step indicators */}
      <div className="flex justify-center gap-2 text-sm">
        <PageNumbers current={step} total={2} />
      </div>
      {step === 1 && (
        <BasicInfoStep form={form} eventType={eventType} onChangeType={setEventType} />
      )}
      {step === 2 && (
        eventType === 'PERFORMANCE' ? (
          <PerformanceDetailsStep form={form} />
        ) : eventType === 'CLASS' ? (
          <ClassWorkshopStep form={form} />
        ) : eventType === 'AUDITION' ? (
          <AuditionStep form={form} />
        ) : (
          <OpportunityStep
            form={form}
            subtype={eventType === 'FUNDING' ? 'FUNDING' : 'CREATIVE'}
          />
        )
      )}

      {submitMessage && (
        <Alert variant={submitMessage.includes('success') ? 'success' : 'error'}>{submitMessage}</Alert>
      )}

      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          {step > 1 && (
            <Button type="button" variant="outline" onClick={goBack}>
              Back
            </Button>
          )}
          {/* If you want Cancel on the left as well, uncomment:
          <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
          */}
        </div>
        <div className="flex gap-2">
          {step === 1 && (
            <Button type="button" variant="primary" onClick={goNext}>
              Next
            </Button>
          )}
          {step === 2 && (
            <Button
              type="button"
              variant="primary"
              onClick={() => {
                handleSubmit()
              }}
              disabled={isSubmitting}
            >
              {isSubmitting ? "Submitting..." : "Submit"}
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}