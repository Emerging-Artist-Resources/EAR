import { z } from "zod"

// Shared base across all forms
// Note: submitterName, submitterPronouns, contactEmail are retrieved from authenticated user session
const baseSchema = z.object({
  submitterName: z.string().optional(),
  submitterPronouns: z.string().optional(),
  contactEmail: z.string().email("Invalid email address").optional().or(z.literal("")),
  company: z.string().optional(),
  companyWebsite: z.string().url("Invalid URL").optional().or(z.literal("")),
  address: z.string().min(1, "Address is required"),
  socialHandles: z.string().min(1, "Social media handles are required"),
  notes: z.string().optional(),
  photoUrls: z.array(z.string().url("Invalid URL")).min(1, "At least one photo URL is required").max(5, "Maximum 5 photo URLs"),
  credits: z.string().min(1, "Image description / credit is required"),
})

// Helpers for nested date/time entries (performance extras)
const extraTimeSchema = z.object({
  time: z.string().min(1, "Time is required"),
})

const extraDateSchema = z.object({
  date: z.string().min(1, "Date is required"),
  times: z.array(extraTimeSchema).min(1, "At least one time is required"),
})

// Performance-only fields (optional in schema; enforced per-step in UI)
const performanceFields = z.object({
  title: z.string().optional(),
  // simple variant date/time (optional; extras are required)
  date: z.string().optional(),
  showTime: z.string().optional(),
  // subtype and festival details
  type: z.enum(["NO", "FESTIVAL", "SPLIT_BILL", "OTHER"]).optional(),
  otherType: z.string().optional(),
  festival_name: z.string().optional(),
  festival_link: z.string().url("Invalid URL").optional(),
  split_bill_name: z.string().optional(),
  split_bill_link: z.string().url("Invalid URL").optional(),
  ticketPrice: z.string().optional(),
  ticketLink: z.string().url("Invalid URL").optional(),
  shortDescription: z.string().max(1000, "Description must be 1000 characters or less").optional(),
  agreeCompTickets: z.boolean().optional(),
  // required nested structure: [{ date, times: [{ time }, ...] }, ...]
  extraOccurrences: z.array(extraDateSchema).min(1, "Add at least one date & time"),
})

// Audition-only
const auditionFields = z.object({
  auditionName: z.string().optional(),
  aboutProject: z.string().optional(),
  eligibility: z.string().optional(),
  compensation: z.string().optional(),
  auditionDate: z.string().optional(),
  auditionTime: z.string().optional(),
  auditionLink: z.string().url("Invalid URL").optional(),
})

// Creative Opportunity-only
const creativeFields = z.object({
  opportunityName: z.string().optional(),
  briefDescription: z.string().max(2000).optional(),
  creativeEligibility: z.string().optional(),
  whatsOffered: z.string().optional(),
  stipendAmount: z.string().optional(),
  requirements: z.string().optional(),
  deadline: z.string().optional(),
  applyLink: z.string().url("Invalid URL").optional(),
})

// Class / Workshop-only
const classFields = z.object({
  festivalName: z.string().optional(),
  festivalLink: z.string().url("Invalid URL").optional(),
  className: z.string().optional(),
  classDates: z.string().optional(),
  classTimes: z.string().optional(),
  classExtraOccurrences: z
    .array(
      z.object({
        date: z.string().min(1, "Date is required"),
        time: z.string().min(1, "Time is required"),
      })
    )
    .optional(),
  classPrices: z.string().optional(),
  classLink: z.string().url("Invalid URL").optional(),
  classDescription: z.string().max(2000).optional(),
  classCreditInfo: z.string().optional(),
  classRecurrence: z.string().optional(),
})

// Funding-only
const fundingFields = z.object({
  fundingLink: z.string().url("Invalid URL").optional(),
  fundingTitle: z.string().optional(),
  fundingSummary: z.string().optional(),
})

export const eventFormSchema = baseSchema
  .merge(performanceFields)
  .merge(auditionFields)
  .merge(creativeFields)
  .merge(classFields)
  .merge(fundingFields)

export type EventFormData = z.infer<typeof eventFormSchema>

// Backwards-compat exports for existing imports
export const performanceSchema = eventFormSchema
export type PerformanceFormData = EventFormData


